//
//  ViewController.swift
//  Roshambo
//
//  Created by Jou-Myu Wijnholds on 18/08/2018.
//  Copyright © 2018 JMWapps. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func rock() {
        let result: resultViewController
        result = storyboard?.instantiateViewController(withIdentifier: "ResultIdentifier") as! resultViewController
        
        present(result, animated: true, completion: nil)
    }
    


}

